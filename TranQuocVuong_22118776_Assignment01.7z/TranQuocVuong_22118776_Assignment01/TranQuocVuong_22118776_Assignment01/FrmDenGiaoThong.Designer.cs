﻿namespace TranQuocVuong_22118776_Assignment01
{
    partial class FrmDenGiaoThong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_top = new System.Windows.Forms.Panel();
            this.lbl_green = new System.Windows.Forms.Label();
            this.btn_ongreen = new System.Windows.Forms.Button();
            this.btn_offgreen = new System.Windows.Forms.Button();
            this.pnl_red = new System.Windows.Forms.Panel();
            this.lbl_red = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_offred = new System.Windows.Forms.Button();
            this.btn_onred = new System.Windows.Forms.Button();
            this.pnl_center = new System.Windows.Forms.Panel();
            this.lbl_yellow = new System.Windows.Forms.Label();
            this.btn_offyellow = new System.Windows.Forms.Button();
            this.btn_onyellow = new System.Windows.Forms.Button();
            this.ptb_green = new System.Windows.Forms.PictureBox();
            this.pnl_top.SuspendLayout();
            this.pnl_red.SuspendLayout();
            this.pnl_center.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_green)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_top
            // 
            this.pnl_top.BackColor = System.Drawing.Color.Lime;
            this.pnl_top.Controls.Add(this.ptb_green);
            this.pnl_top.Controls.Add(this.lbl_green);
            this.pnl_top.Controls.Add(this.btn_ongreen);
            this.pnl_top.Controls.Add(this.btn_offgreen);
            this.pnl_top.Location = new System.Drawing.Point(0, 0);
            this.pnl_top.Name = "pnl_top";
            this.pnl_top.Size = new System.Drawing.Size(801, 179);
            this.pnl_top.TabIndex = 0;
            this.pnl_top.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_top_Paint);
            // 
            // lbl_green
            // 
            this.lbl_green.AutoSize = true;
            this.lbl_green.Location = new System.Drawing.Point(365, 93);
            this.lbl_green.Name = "lbl_green";
            this.lbl_green.Size = new System.Drawing.Size(96, 13);
            this.lbl_green.TabIndex = 2;
            this.lbl_green.Text = "chuyen sau 20giay";
            // 
            // btn_ongreen
            // 
            this.btn_ongreen.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_ongreen.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_ongreen.Location = new System.Drawing.Point(86, 70);
            this.btn_ongreen.Name = "btn_ongreen";
            this.btn_ongreen.Size = new System.Drawing.Size(117, 58);
            this.btn_ongreen.TabIndex = 1;
            this.btn_ongreen.Text = "ON";
            this.btn_ongreen.UseVisualStyleBackColor = false;
            // 
            // btn_offgreen
            // 
            this.btn_offgreen.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_offgreen.Location = new System.Drawing.Point(576, 70);
            this.btn_offgreen.Name = "btn_offgreen";
            this.btn_offgreen.Size = new System.Drawing.Size(121, 58);
            this.btn_offgreen.TabIndex = 0;
            this.btn_offgreen.Text = "OFF";
            this.btn_offgreen.UseVisualStyleBackColor = false;
            // 
            // pnl_red
            // 
            this.pnl_red.BackColor = System.Drawing.Color.Red;
            this.pnl_red.Controls.Add(this.lbl_red);
            this.pnl_red.Controls.Add(this.label3);
            this.pnl_red.Controls.Add(this.btn_offred);
            this.pnl_red.Controls.Add(this.btn_onred);
            this.pnl_red.Location = new System.Drawing.Point(0, 312);
            this.pnl_red.Name = "pnl_red";
            this.pnl_red.Size = new System.Drawing.Size(801, 138);
            this.pnl_red.TabIndex = 0;
            // 
            // lbl_red
            // 
            this.lbl_red.AutoSize = true;
            this.lbl_red.Location = new System.Drawing.Point(365, 64);
            this.lbl_red.Name = "lbl_red";
            this.lbl_red.Size = new System.Drawing.Size(82, 13);
            this.lbl_red.TabIndex = 5;
            this.lbl_red.Text = "chuyen sau 20s";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";
            // 
            // btn_offred
            // 
            this.btn_offred.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_offred.Location = new System.Drawing.Point(576, 41);
            this.btn_offred.Name = "btn_offred";
            this.btn_offred.Size = new System.Drawing.Size(121, 58);
            this.btn_offred.TabIndex = 3;
            this.btn_offred.Text = "OFF";
            this.btn_offred.UseVisualStyleBackColor = false;
            // 
            // btn_onred
            // 
            this.btn_onred.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_onred.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_onred.Location = new System.Drawing.Point(86, 41);
            this.btn_onred.Name = "btn_onred";
            this.btn_onred.Size = new System.Drawing.Size(117, 58);
            this.btn_onred.TabIndex = 2;
            this.btn_onred.Text = "ON";
            this.btn_onred.UseVisualStyleBackColor = false;
            // 
            // pnl_center
            // 
            this.pnl_center.BackColor = System.Drawing.Color.Yellow;
            this.pnl_center.Controls.Add(this.lbl_yellow);
            this.pnl_center.Controls.Add(this.btn_offyellow);
            this.pnl_center.Controls.Add(this.btn_onyellow);
            this.pnl_center.Location = new System.Drawing.Point(3, 174);
            this.pnl_center.Name = "pnl_center";
            this.pnl_center.Size = new System.Drawing.Size(798, 144);
            this.pnl_center.TabIndex = 0;
            // 
            // lbl_yellow
            // 
            this.lbl_yellow.AutoSize = true;
            this.lbl_yellow.Location = new System.Drawing.Point(362, 54);
            this.lbl_yellow.Name = "lbl_yellow";
            this.lbl_yellow.Size = new System.Drawing.Size(76, 13);
            this.lbl_yellow.TabIndex = 3;
            this.lbl_yellow.Text = "chuyen sau 5s";
            // 
            // btn_offyellow
            // 
            this.btn_offyellow.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_offyellow.Location = new System.Drawing.Point(573, 31);
            this.btn_offyellow.Name = "btn_offyellow";
            this.btn_offyellow.Size = new System.Drawing.Size(121, 58);
            this.btn_offyellow.TabIndex = 3;
            this.btn_offyellow.Text = "OFF";
            this.btn_offyellow.UseVisualStyleBackColor = false;
            // 
            // btn_onyellow
            // 
            this.btn_onyellow.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_onyellow.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_onyellow.Location = new System.Drawing.Point(83, 31);
            this.btn_onyellow.Name = "btn_onyellow";
            this.btn_onyellow.Size = new System.Drawing.Size(117, 58);
            this.btn_onyellow.TabIndex = 2;
            this.btn_onyellow.Text = "ON";
            this.btn_onyellow.UseVisualStyleBackColor = false;
            // 
            // ptb_green
            // 
            this.ptb_green.BackColor = System.Drawing.Color.GreenYellow;
            this.ptb_green.Location = new System.Drawing.Point(254, 12);
            this.ptb_green.Name = "ptb_green";
            this.ptb_green.Size = new System.Drawing.Size(305, 50);
            this.ptb_green.TabIndex = 3;
            this.ptb_green.TabStop = false;
            // 
            // FrmDenGiaoThong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl_center);
            this.Controls.Add(this.pnl_red);
            this.Controls.Add(this.pnl_top);
            this.Name = "FrmDenGiaoThong";
            this.Text = "DenGiaoThong";
            this.pnl_top.ResumeLayout(false);
            this.pnl_top.PerformLayout();
            this.pnl_red.ResumeLayout(false);
            this.pnl_red.PerformLayout();
            this.pnl_center.ResumeLayout(false);
            this.pnl_center.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_green)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_top;
        private System.Windows.Forms.Panel pnl_red;
        private System.Windows.Forms.Button btn_ongreen;
        private System.Windows.Forms.Button btn_offgreen;
        private System.Windows.Forms.Button btn_offred;
        private System.Windows.Forms.Button btn_onred;
        private System.Windows.Forms.Panel pnl_center;
        private System.Windows.Forms.Button btn_offyellow;
        private System.Windows.Forms.Button btn_onyellow;
        private System.Windows.Forms.Label lbl_green;
        private System.Windows.Forms.Label lbl_red;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_yellow;
        private System.Windows.Forms.PictureBox ptb_green;
    }
}

