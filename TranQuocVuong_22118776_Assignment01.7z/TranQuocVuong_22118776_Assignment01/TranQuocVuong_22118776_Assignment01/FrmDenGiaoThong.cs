﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TranQuocVuong_22118776_Assignment01
{
    public partial class FrmDenGiaoThong : Form
    {
        public FrmDenGiaoThong()
        {
            InitializeComponent();
        }

        private void pnl_top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
